"""
PROGETTO: Tratto Password Sicure
CATEGORIA: Sicurezza Informatica
AUTORE: Francesco Piroddi
TITOLARE: Francesco Piroddi
CODICE FISCALE: PRDFNC94L03E441D
LICENZA: GNU General Public License (GPL) v3.0
COPYRIGHT: © 2026 Francesco Piroddi. Tutti i diritti riservati.

CONFORMITÀ NORMATIVA E STANDARD:
- Repubblica Italiana: Legge 633/1941 (Diritto d'Autore).
- Unione Europea: GDPR (UE 2016/679) - Privacy by Design.
- Internazionale: Standard NIST SP 800-90A, ISO/IEC 27001.
"""

import customtkinter as ctk
import secrets
import string
import pyperclip
from tkinter import messagebox

class TrattoPasswordSicure(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Configurazione Finestra Principale
        self.title("Tratto Password Sicure - Francesco Piroddi")
        self.geometry("500x600")
        self.resizable(False, False)

        # Impostazione Estetica Black & White
        ctk.set_appearance_mode("dark") 
        self.bg_color = "#000000"
        self.fg_color = "#FFFFFF"
        self.configure(fg_color=self.bg_color)

        self.setup_ui()

    def setup_ui(self):
        # Header - Titolo e Proprietà
        self.lbl_title = ctk.CTkLabel(
            self, text="TRATTO PASSWORD SICURE", 
            font=("Helvetica", 24, "bold"), text_color=self.fg_color
        )
        self.lbl_title.pack(pady=(40, 5))

        self.lbl_owner = ctk.CTkLabel(
            self, text="Autore: Francesco Piroddi | CF: PRDFNC94L03E441D", 
            font=("Helvetica", 11), text_color=self.fg_color
        )
        self.lbl_owner.pack(pady=(0, 20))

        # Output Password
        self.entry_pw = ctk.CTkEntry(
            self, width=400, height=50, font=("Courier", 20, "bold"),
            fg_color=self.bg_color, border_color=self.fg_color,
            text_color=self.fg_color, justify="center"
        )
        self.entry_pw.pack(pady=20)

        # Selezione Lunghezza
        self.lbl_len = ctk.CTkLabel(self, text="Lunghezza Password: 20", text_color=self.fg_color)
        self.lbl_len.pack()
        
        self.slider = ctk.CTkSlider(
            self, from_=8, to_=64, number_of_steps=56,
            button_color=self.fg_color, progress_color=self.fg_color,
            command=self.update_slider_text
        )
        self.slider.set(20)
        self.slider.pack(pady=10, padx=50)

        # Opzioni di Generazione
        self.frame_opts = ctk.CTkFrame(self, fg_color="transparent")
        self.frame_opts.pack(pady=20)

        self.check_upper = self.create_bw_checkbox("Include Maiuscole (A-Z)")
        self.check_nums = self.create_bw_checkbox("Include Numeri (0-9)")
        self.check_syms = self.create_bw_checkbox("Include Simboli (!?@#$)")

        # Bottoni Azione
        self.btn_gen = ctk.CTkButton(
            self, text="GENERA", font=("Helvetica", 16, "bold"),
            fg_color=self.fg_color, text_color=self.bg_color,
            hover_color="#DDDDDD", command=self.generate
        )
        self.btn_gen.pack(pady=20)

        self.btn_copy = ctk.CTkButton(
            self, text="COPIA NEGLI APPUNTI", 
            fg_color="transparent", border_width=1, border_color=self.fg_color,
            text_color=self.fg_color, hover_color="#333333",
            command=self.copy_to_clipboard
        )
        self.btn_copy.pack(pady=5)

        # Footer Legale
        footer_info = (
            "Standard: ISO/IEC 27001 - NIST - GDPR - LdA (IT)\n"
            "Licenza GNU GPL v3.0 | Proprietà di Francesco Piroddi"
        )
        self.lbl_footer = ctk.CTkLabel(
            self, text=footer_info, font=("Helvetica", 9), 
            text_color="gray", justify="center"
        )
        self.lbl_footer.pack(side="bottom", pady=20)

    def create_bw_checkbox(self, text):
        cb = ctk.CTkCheckBox(
            self.frame_opts, text=text, border_color=self.fg_color,
            fg_color=self.fg_color, checkmark_color=self.bg_color,
            text_color=self.fg_color
        )
        cb.select()
        cb.pack(pady=5, anchor="w")
        return cb

    def update_slider_text(self, val):
        self.lbl_len.configure(text=f"Lunghezza Password: {int(val)}")

    def generate(self):
        """Logica di generazione sicura conforme agli standard crittografici."""
        pool = string.ascii_lowercase
        if self.check_upper.get(): pool += string.ascii_uppercase
        if self.check_nums.get(): pool += string.digits
        if self.check_syms.get(): pool += string.punctuation

        length = int(self.slider.get())
        #secrets.choice garantisce una casualità crittograficamente sicura (CSPRNG)
        password = "".join(secrets.choice(pool) for _ in range(length))
        
        self.entry_pw.delete(0, 'end')
        self.entry_pw.insert(0, password)

    def copy_to_clipboard(self):
        pw = self.entry_pw.get()
        if pw:
            pyperclip.copy(pw)
            messagebox.showinfo("Successo", "Password copiata negli appunti.")

if __name__ == "__main__":
    app = TrattoPasswordSicure()
    app.mainloop()